

const http = require('http');
const url = require('url');
const fs = require('fs');
const { Pool } = require('pg');

const PORT = 3000;

// PostgreSQL database connection pool
const pool = new Pool({

  user: 'postgres',
  host: 'localhost',
  database: 'Vet Clinic_lab3',
  password: '1234',
  port: 5433

});

// Generate a unique patient ID

let nextPatientId = 1;

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const { pathname } = parsedUrl;

  if (req.method === 'GET' && pathname === '/') {
    
    fs.readFile('lab3.html', (err, data) => {
      if (err) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Internal Server Error');
      } else {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(data);
      }
    });
  } else if (req.method === 'POST' && pathname === '/patients') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();
    });

    req.on('end', () => {
      try {
        const patientData = JSON.parse(body);
        if (!patientData.name || !patientData.species || !patientData.age || !patientData.sickness) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Please provide all required information.' }));
        } else {
          const patient = {
            id: nextPatientId++,
            name: patientData.name,
            species: patientData.species,
            age: patientData.age,
            sickness: patientData.sickness,
            created_at: new Date(),
            updated_at: new Date(),
          };

          // Insert the patient data into the PostgreSQL database
          pool.query(
            'INSERT INTO vet_clinic (name, species, age, sickness, created_at, updated_at) VALUES ($1, $2, $3, $4, $5, $6) RETURNING id',
            [patient.name, patient.species, patient.age, patient.sickness, patient.created_at, patient.updated_at],
            (err, dbRes) => {
              if (err) {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Error storing patient data.' }));
              } else {
                patient.id = dbRes.rows[0].id;
                res.writeHead(201, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ message: 'Patient created successfully', patient }));
              }
            }
          );
        }
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON data.' }));
      }
    });
  } else if ((req.method === 'PUT' || req.method === 'PATCH') && pathname.startsWith('/patients/')) {
    const patientId = parseInt(pathname.slice(10), 10);
    const patient = patients.find((p) => p.id === patientId);

    if (!patient) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Patient not found.' }));
    } else {
      let body = '';
      req.on('data', (chunk) => {
        body += chunk.toString();
      });

      req.on('end', () => {
        try {
          const patientData = JSON.parse(body);

          if (patientData.name) patient.name = patientData.name;
          if (patientData.species) patient.species = patientData.species;
          if (patientData.age) patient.age = patientData.age;
          if (patientData.sickness) patient.sickness = patientData.sickness;

          patient.updated_at = new Date();

          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ message: 'Patient updated successfully', patient }));
        } catch (err) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Invalid JSON data.' }));

        }
      });
    }
  } else {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not Found' }));
  }
});

server.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);


});
